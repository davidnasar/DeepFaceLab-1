from models import ModelBase
from models import TrainingDataType
import numpy as np
import cv2

from nnlib import DSSIMMaskLossClass
from nnlib import tf_dssim
from nnlib import conv
from nnlib import upscale
from facelib import FaceType

class Model(ModelBase):

    encoderH5 = 'encoder.h5'
    decoder_srcH5 = 'decoder_src.h5'
    decoder_dstH5 = 'decoder_dst.h5'
    decoder_src_maskH5 = 'decoder_src_mask.h5'
    decoder_dst_maskH5 = 'decoder_dst_mask.h5'

    #override
    def onInitialize(self, **in_options):
        tf = self.tf
        keras = self.keras
        K = keras.backend
        
        self.set_vram_batch_requirements( {4.5:8,5:8,6:8,7:8,8:16,9:16,10:24,11:24,12:32,13:48} )
                
        img_shape = (64, 64, 3)
        img_mask_shape = (64, 64, 1)
        img_input = self.keras.layers.Input(img_shape)
        
        self.encoder = self.Encoder(img_input)
        self.decoder_src = self.Decoder()
        self.decoder_src_mask = self.Decoder_mask()
        self.decoder_dst = self.Decoder()        
        self.decoder_dst_mask = self.Decoder_mask() 
        
        if not self.is_first_run():
            self.encoder.load_weights     (self.get_strpath_storage_for_file(self.encoderH5))
            self.decoder_src.load_weights (self.get_strpath_storage_for_file(self.decoder_srcH5))
            self.decoder_src_mask.load_weights (self.get_strpath_storage_for_file(self.decoder_src_maskH5))
            self.decoder_dst.load_weights (self.get_strpath_storage_for_file(self.decoder_dstH5))
            self.decoder_dst_mask.load_weights (self.get_strpath_storage_for_file(self.decoder_dst_maskH5))

        input_src_warped = self.keras.layers.Input(img_shape)
        input_src_target = self.keras.layers.Input(img_shape)
        input_src_target_mask = self.keras.layers.Input(img_mask_shape)
        input_dst_warped = self.keras.layers.Input(img_shape)
        input_dst_target = self.keras.layers.Input(img_shape)
        input_dst_target_mask = self.keras.layers.Input(img_mask_shape)
        
        src_code = self.encoder(input_src_warped)
        rec_src = self.decoder_src(src_code)
        rec_src_mask = self.decoder_src_mask(src_code)
        
        dst_code = self.encoder(input_dst_warped)
        rec_dst = self.decoder_dst(dst_code)
        rec_dst_mask = self.decoder_dst_mask(dst_code)
        
        #tf_dssim(tf, (input_src_target)*(rec_src_mask), (rec_src)*(rec_src_mask)) + \
                  #tf_dssim(tf, (input_dst_warped)*(rec_dst_mask), (rec_dst)*(rec_dst_mask)) + \
        #src_loss = tf_dssim(tf, input_src_target*input_src_target_mask, rec_src*input_src_target_mask)
        #dst_loss = tf_dssim(tf, input_dst_warped*input_dst_target_mask, rec_dst*input_dst_target_mask)
        src_loss = K.mean( K.square( input_src_target*input_src_target_mask - rec_src*input_src_target_mask) )
        dst_loss = K.mean( K.square( input_dst_warped*input_dst_target_mask - rec_dst*input_dst_target_mask) )
        
        mask_src_loss = K.mean( K.square( input_src_warped * rec_src_mask - rec_src ) )
        mask_dst_loss = K.mean( K.square( input_dst_warped * rec_dst_mask - rec_dst ) )
                  
        self.src_train = K.function ([input_src_warped, input_src_target, input_src_target_mask],[src_loss],
                                       self.keras.optimizers.Adam(lr=5e-5, beta_1=0.5, beta_2=0.999).get_updates(src_loss, self.encoder.trainable_weights + self.decoder_src.trainable_weights)
                                     )
         
        self.dst_train = K.function ([input_dst_warped, input_dst_target, input_dst_target_mask],[dst_loss],
                                       self.keras.optimizers.Adam(lr=5e-5, beta_1=0.5, beta_2=0.999).get_updates(dst_loss, self.encoder.trainable_weights + self.decoder_dst.trainable_weights)
                                     )
                                     
        self.src_mask_train = K.function ([input_src_warped, input_src_target],[mask_src_loss],
                                       self.keras.optimizers.Adam(lr=5e-5, beta_1=0.5, beta_2=0.999).get_updates(mask_src_loss, self.decoder_src_mask.trainable_weights)
                                     )
        self.dst_mask_train = K.function ([input_dst_warped, input_dst_target],[mask_dst_loss],
                                       self.keras.optimizers.Adam(lr=5e-5, beta_1=0.5, beta_2=0.999).get_updates(mask_dst_loss, self.decoder_dst_mask.trainable_weights)
                                     )                             
        self.ae_view = K.function ([input_src_warped,  input_dst_warped], [rec_src, rec_src_mask, rec_dst, rec_dst_mask])
        self.ae_conv = K.function ([input_dst_warped], [rec_dst])
       
        if self.is_training_mode:
            from models import TrainingDataGenerator
            f = TrainingDataGenerator.SampleTypeFlags 
            self.set_training_data_generators ([            
                    TrainingDataGenerator(TrainingDataType.FACE, self.training_data_src_path, debug=self.is_debug(), batch_size=self.batch_size, output_sample_types=[ [f.WARPED_TRANSFORMED | f.HALF_FACE | f.MODE_BGR, 64], [f.TRANSFORMED | f.HALF_FACE | f.MODE_BGR, 64], [f.TRANSFORMED | f.HALF_FACE | f.MODE_M | f.MASK_FULL, 64] ], random_flip=True ),
                    TrainingDataGenerator(TrainingDataType.FACE, self.training_data_dst_path, debug=self.is_debug(), batch_size=self.batch_size, output_sample_types=[ [f.WARPED_TRANSFORMED | f.HALF_FACE | f.MODE_BGR, 64], [f.TRANSFORMED | f.HALF_FACE | f.MODE_BGR, 64], [f.TRANSFORMED | f.HALF_FACE | f.MODE_M | f.MASK_FULL, 64] ], random_flip=True )
                ])
    #override
    def onSave(self):        
        self.save_weights_safe( [[self.encoder, self.get_strpath_storage_for_file(self.encoderH5)],
                                [self.decoder_src, self.get_strpath_storage_for_file(self.decoder_srcH5)],
                                [self.decoder_src_mask, self.get_strpath_storage_for_file(self.decoder_src_maskH5)],
                                [self.decoder_dst, self.get_strpath_storage_for_file(self.decoder_dstH5)],
                                [self.decoder_dst_mask, self.get_strpath_storage_for_file(self.decoder_dst_maskH5)]
                                ] )
        
    #override
    def onTrainOneEpoch(self, sample):
        warped_src, target_src, target_src_mask = sample[0]
        warped_dst, target_dst, target_dst_mask = sample[1]    
  
        src_loss = self.src_train([warped_src, target_src, target_src_mask])[0].mean()
        dst_loss = self.dst_train([warped_dst, target_dst, target_dst_mask])[0].mean()
        
        src_mask_loss = self.src_mask_train([warped_src, target_src])[0].mean()
        dst_mask_loss = self.dst_mask_train([warped_dst, target_dst])[0].mean()
        return ( ('src', src_loss), ('dst', dst_loss), ('srcm', src_mask_loss), ('dstm', dst_mask_loss) )        

    #override
    def onGetPreview(self, sample):
        test_A   = sample[0][1][0:4] #first 4 samples
        test_A_m = sample[0][2][0:4] #first 4 samples
        test_B   = sample[1][1][0:4]
        test_B_m = sample[1][2][0:4]
        
        AA, AA_m, BB, BB_m = self.ae_view ([test_A, test_B])
        AB, AB_m, BA, BA_m = self.ae_view ([test_B, test_A])
        
        #test_A, test_B, AA, BB, AB, BA = [ np.clip(x / 2 + 0.5, 0.0, 1.0) for x in [test_A, test_B, AA, BB, AB, BA] ]

        AA_m = np.repeat ( AA_m, (3,), -1)
        BB_m = np.repeat ( BB_m, (3,), -1)
        AB_m = np.repeat ( AB_m, (3,), -1)
        BA_m = np.repeat ( BA_m, (3,), -1)
        
        st = []
        for i in range(0, len(test_A)):
            st.append ( np.concatenate ( (
                test_A[i,:,:,0:3],
                AA[i], AA_m[i],
                test_B[i,:,:,0:3], 
                BB[i], BB_m[i],
                AB[i], AB_m[i]
                ), axis=1) )
            
        return [ ('DF', np.concatenate ( st, axis=0 ) ) ]
    
    def predictor_func (self, face):
        
        face_128_bgr = face[...,0:3]
        face_128_mask = np.expand_dims(face[...,3],-1)
        
        x, mx = self.autoencoder_src.predict ( [ np.expand_dims(face_128_bgr,0), np.expand_dims(face_128_mask,0) ] )
        x, mx = x[0], mx[0]
        
        return np.concatenate ( (x,mx), -1 )
        
    #override
    def get_converter(self, **in_options):
        from models import ConverterMasked
        
        if 'erode_mask_modifier' not in in_options.keys():
            in_options['erode_mask_modifier'] = 0
        in_options['erode_mask_modifier'] += 30################
            
        if 'blur_mask_modifier' not in in_options.keys():
            in_options['blur_mask_modifier'] = 0
            
        return ConverterMasked(self.predictor_func, predictor_input_size=64, output_size=64, face_type=FaceType.HALF, clip_border_mask_per=0.046875, **in_options)
        
    def Encoder(self, input_layer):
        x = input_layer
        x = conv(self.keras, x, 128)
        x = conv(self.keras, x, 256)
        x = conv(self.keras, x, 512)
        x = conv(self.keras, x, 1024)

        x = self.keras.layers.Dense(512)(self.keras.layers.Flatten()(x))
        x = self.keras.layers.Dense(4 * 4 * 512)(x)
        x = self.keras.layers.Reshape((4, 4, 512))(x)
        x = upscale(self.keras, x, 512)
            
        return self.keras.models.Model(input_layer, x)

    def Decoder(self):
        input_ = self.keras.layers.Input(shape=(8, 8, 512))
        x = input_
        x = upscale(self.keras, x, 512)
        x = upscale(self.keras, x, 256)
        x = upscale(self.keras, x, 128)
    
        x = self.keras.layers.convolutional.Conv2D(3, kernel_size=5, padding='same', activation='sigmoid')(x)
    
        return self.keras.models.Model(input_, x)
    
    def Decoder_mask(self):
        input_ = self.keras.layers.Input(shape=(8, 8, 512))
      
        y = input_  #mask decoder
        y = upscale(self.keras, y, 512)
        y = upscale(self.keras, y, 256)
        y = upscale(self.keras, y, 128)
        y = self.keras.layers.convolutional.Conv2D(1, kernel_size=5, padding='same', activation='sigmoid')(y)
        
        return self.keras.models.Model(input_, y)